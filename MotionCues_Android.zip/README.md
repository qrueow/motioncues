# MotionCues — защита от укачивания (Android, Kotlin + Jetpack Compose)

Аналог Apple Vehicle Motion Cues / KineStop: периферийная сетка точек поверх
экрана, синхронизированная с реальным ускорением и вращением телефона.

## Почему Android, а не iOS/Flutter

- **Overlay поверх других приложений** (карты, YouTube, Instagram и т.д.)
  технически возможен только через `WindowManager` + `TYPE_APPLICATION_OVERLAY`.
  На iOS сторонние приложения **не могут** рисовать поверх других приложений —
  это ограничение платформы, а не техническое решение проекта.
- Flutter добавляет прослойку между сенсорами и рендером (platform channel
  latency), что критично при задаче "0 задержки между реальным поворотом
  и визуальным cue" — поэтому нативный Kotlin с прямым доступом к
  `SensorManager` и Compose `Canvas`.

## Структура проекта

```
MotionCues/
├── build.gradle.kts                  # версии AGP/Kotlin плагинов
├── settings.gradle.kts               # репозитории, модуль :app
├── gradle.properties
└── app/
    ├── build.gradle.kts              # зависимости (Compose, Play Services Location)
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml       # все разрешения + декларация сервиса
        ├── java/com/motioncues/
        │   ├── MotionCuesApp.kt              # Application, регистрирует DrivingDetector
        │   ├── MainActivity.kt               # UI онбординга разрешений + ручной toggle
        │   ├── sensor/
        │   │   ├── KalmanFilter1D.kt         # переиспользуемый скалярный фильтр Калмана
        │   │   └── SensorFusionEngine.kt     # чтение accel+gyro, фильтрация, MotionCueVector
        │   ├── overlay/
        │   │   ├── OverlayService.kt         # Foreground Service + WindowManager overlay
        │   │   └── MotionCuesCanvas.kt       # Compose Canvas — анимация точек 60 FPS
        │   └── activity/
        │       ├── DrivingDetector.kt        # ActivityRecognitionClient (авто старт/стоп)
        │       └── BootCompletedReceiver.kt  # ре-регистрация после перезагрузки
        └── res/
            ├── values/strings.xml
            ├── values/themes.xml
            └── drawable/ic_notification_dot.xml
```

## Как собрать

1. Открой Android Studio (Koala+) → **Open** → выбери папку `MotionCues/`.
2. Дай Gradle синхронизироваться (подтянет Compose BOM 2024.06.00,
   `play-services-location:21.3.0`, Kotlin 1.9.24, AGP 8.5.0).
3. Подключи физическое устройство (эмулятор не даёт реальных данных
   акселерометра/гироскопа — тестировать нужно на живом телефоне).
4. Run ▶ на `app`.
5. При первом запуске пройди 3 шага онбординга:
   - **Оверлей** — откроется системная страница "Отображение поверх других
     приложений", включи тумблер вручную (Android не позволяет получить
     это разрешение программно).
   - **Activity Recognition** — стандартный runtime-permission диалог.
   - **Уведомления** — обязателен на Android 13+, иначе foreground service
     не сможет стартовать.
6. Нажми "Запустить вручную (тест)" — на экране появится вращающееся
   кольцо точек по периметру экрана. Наклони/поверни телефон — точки
   должны сместиться с задержкой ~90 мс и без дребезга.

## Математика (кратко, без базовой теории — только то, что реализовано)

- `TYPE_LINEAR_ACCELERATION` уже вычитает гравитацию на уровне ОС (sensor
  fusion Android), поэтому Kalman-фильтр в `KalmanFilter1D` работает над
  уже "чистым" сигналом, а не сырым accel+gravity.
- Отдельные фильтры на X (боковое), Y (продольное) ускорение и на Z-ось
  гироскопа (yaw rate) — совместный 6-компонентный Kalman намеренно не
  использован, т.к. корреляции между осями в задаче "cue для вестибулярки"
  не дают ощутимого выигрыша, а раздельные фильтры на порядок дешевле по
  CPU и проще тюнить `Q/R` под конкретную ось.
- **Адаптивный R**: при росте магнитуды сигнала (`|X|+|Y| > 1.2`) фильтр
  снижает `measurementNoise`, то есть начинает быстрее доверять сырым
  данным — так резкое торможение не "срезается" сглаживанием, которое
  иначе давило бы дорожную тряску.
- `vibrationFloor` — экспоненциальное скользящее среднее магнитуды,
  используется как адаптивный порог: то, что ниже текущего фона вибрации
  (тряска на грунтовке), не подсвечивается как "событие" (`intensity`).
- Нормализация в UI-диапазон `[-1, 1]` идёт по эмпирическим порогам
  `MAX_LATERAL_MS2 = 3.5`, `MAX_LONGITUDINAL_MS2 = 4.0` (м/с²) — это
  примерно комфортные пределы бокового/продольного ускорения легкового
  авто; при необходимости откалибруй под конкретный тип транспорта
  (автобус/поезд потребуют других порогов).

## Сборка .apk прямо с телефона (без ПК)

Полноценная сборка Compose/AGP-проекта через Termux на самом телефоне
технически возможна, но крайне болезненна: нужен нативный `aapt2` под ARM,
Android SDK command-line tools, JDK 17, и сборка Compose-проекта на слабом
CPU телефона легко занимает 20-40+ минут с риском упасть по памяти.
Практичный способ — **собрать APK в облаке через GitHub Actions**, а с
телефона только запушить код и скачать готовый файл. Реальная сборка идёт
не на телефоне, а на сервере GitHub — с телефона нужны только git push и
скачивание файла из браузера/приложения GitHub.

В проект уже добавлен `.github/workflows/build-apk.yml` — он автоматически
собирает `app-debug.apk` при каждом push и кладёт его как Artifact.

### Шаг 1 — создай репозиторий на GitHub

1. В приложении **GitHub** (Play Store) или в мобильном браузере зайди на
   github.com → **New repository** → назови, например, `motioncues` →
   **Private** (чтобы код не был публичным) → Create.
2. Открой **Settings → Developer settings → Personal access tokens →
   Tokens (classic)** → **Generate new token** → отметь scope `repo` →
   сгенерируй и **скопируй токен** (он показывается один раз).

### Шаг 2 — установи Termux и запушь код

1. Поставь **Termux** из F-Droid (в Play Store версия устаревшая и не
   обновляется).
2. В Termux:
   ```bash
   pkg update && pkg install git -y
   ```
3. Перенеси распакованную папку `MotionCues/` на телефон (например, через
   `Downloads`), затем в Termux:
   ```bash
   termux-setup-storage
   cp -r /sdcard/Download/MotionCues ~/MotionCues
   cd ~/MotionCues
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/ТВОЙ_ЛОГИН/motioncues.git
   ```
4. Пуш с токеном вместо пароля:
   ```bash
   git push -u origin main
   # Username: твой GitHub логин
   # Password: вставь personal access token из шага 1 (не обычный пароль)
   ```

### Шаг 3 — сборка запустится автоматически

1. Открой репозиторий в приложении GitHub → вкладка **Actions** → увидишь
   запущенный workflow **Build APK** (жёлтый = идёт, зелёный = готово,
   обычно 3-6 минут).
2. Если нужно перезапустить сборку без нового push — вкладка **Actions →
   Build APK → Run workflow** (кнопка появляется благодаря
   `workflow_dispatch` в yml).

### Шаг 4 — скачай и установи APK

1. В завершённом workflow открой раздел **Artifacts** → скачай
   `MotionCues-debug-apk.zip` (GitHub всегда зипует артефакты, внутри —
   обычный `app-debug.apk`).
2. Распакуй (любой файловый менеджер с поддержкой zip, либо
   встроенный в Android), открой `.apk`.
3. При первой установке система попросит включить **"Разрешить установку
   из этого источника"** для приложения-файлового менеджера/браузера —
   подтверди.
4. После установки пройди онбординг разрешений внутри приложения (см.
   раздел "Как собрать" выше — шаги 5-6 те же).

### Если что-то меняешь в коде и хочешь пересобрать

```bash
cd ~/MotionCues
# отредактируй файлы прямо в Termux (nano/vim) или через любой текстовый редактор
git add .
git commit -m "update"
git push
```
Новый push автоматически запускает новую сборку — жди появления Artifact
на вкладке Actions.

## Известные ограничения и что доработать под публикацию в Google Play

- `FOREGROUND_SERVICE_SPECIAL_USE` требует явного описания use-case в
  Play Console при публикации (текст уже указан в манифесте через
  `PROPERTY_SPECIAL_USE_FGS_SUBTYPE`) — Google review иногда просит
  дополнительное видео-демо для этой категории.
- `SYSTEM_ALERT_WINDOW` больше не в списке "restricted permissions", но
  Play Console всё равно попросит Permission Declaration Form с описанием,
  зачем оверлей нужен (health/accessibility use-case).
- Батарея: непрерывный опрос сенсоров на `SENSOR_DELAY_GAME` (~50 Гц)
  ощутимо расходует заряд за долгую поездку — стоит добавить экран
  настроек с выбором частоты (Eco/Normal/High) — сейчас захардкожено
  в `SensorFusionEngine.start()`.
- Иконка приложения (`ic_launcher`) — placeholder не включён, добавь через
  Android Studio → New → Image Asset.
