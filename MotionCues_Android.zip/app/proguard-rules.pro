# Compose/Kotlin reflection не используется агрессивно — базовых правил AGP достаточно.
-keep class com.motioncues.** { *; }
