package com.motioncues.sensor

/**
 * Классический скалярный фильтр Калмана для одной оси сенсорного сигнала.
 * Используется отдельно для X/Y/Z линейного ускорения и для yaw-rate гироскопа.
 *
 * processNoise (Q)   — насколько мы доверяем модели движения (больше = более "живая" реакция)
 * measurementNoise (R) — насколько мы доверяем сырому измерению (больше = сильнее сглаживание)
 *
 * Для дорожной вибрации типичные значения: Q ~ 0.008, R ~ 0.35
 * Для резких маневров (торможение/поворот) можно адаптивно уменьшать R.
 */
class KalmanFilter1D(
    private var processNoise: Double = 0.008,
    private var measurementNoise: Double = 0.35,
    initialEstimate: Double = 0.0,
    initialErrorCovariance: Double = 1.0
) {
    private var estimate: Double = initialEstimate
    private var errorCovariance: Double = initialErrorCovariance

    /**
     * Обновление фильтра новым сырым измерением.
     * Возвращает сглаженную оценку.
     */
    fun update(measurement: Double): Double {
        // --- Prediction step ---
        // Модель движения статична (без сложной кинематической модели транспорта),
        // поэтому предсказанное состояние = предыдущая оценка.
        val predictedEstimate = estimate
        val predictedErrorCovariance = errorCovariance + processNoise

        // --- Update (correction) step ---
        val kalmanGain = predictedErrorCovariance / (predictedErrorCovariance + measurementNoise)
        estimate = predictedEstimate + kalmanGain * (measurement - predictedEstimate)
        errorCovariance = (1 - kalmanGain) * predictedErrorCovariance

        return estimate
    }

    /**
     * Адаптивная настройка шума измерения "на лету".
     * Позволяет фильтру реагировать быстрее на резкие манёвры
     * и сильнее давить дребезг на ровной дороге.
     */
    fun setMeasurementNoise(r: Double) {
        measurementNoise = r.coerceIn(0.05, 2.0)
    }

    fun reset(value: Double = 0.0) {
        estimate = value
        errorCovariance = 1.0
    }

    fun currentEstimate(): Double = estimate
}
