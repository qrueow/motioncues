package com.motioncues.sensor

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Итоговый вектор "сигнала укачивания" (motion cue), потребляемый UI-слоем.
 *
 * lateralOffset   — боковое смещение точек (реакция на повороты), диапазон [-1, 1]
 * longitudinalOffset — продольное смещение (реакция на торможение/разгон), диапазон [-1, 1]
 * yawRate         — сглаженная угловая скорость вокруг вертикальной оси (рад/с)
 * intensity       — суммарная "сила" события 0..1, используется для яркости/размера точек
 */
data class MotionCueVector(
    val lateralOffset: Float = 0f,
    val longitudinalOffset: Float = 0f,
    val yawRate: Float = 0f,
    val intensity: Float = 0f,
    val timestampNs: Long = 0L
)

/**
 * Состояние движения транспортного средства (для авто старт/стоп).
 */
enum class VehicleMotionState { IDLE, DRIVING }

/**
 * Сервис-синглтон, инкапсулирующий:
 *  - подписку на TYPE_LINEAR_ACCELERATION (гравитация уже вычтена системой)
 *  - подписку на TYPE_GYROSCOPE
 *  - калмановскую фильтрацию по 3 осям ускорения + yaw
 *  - эвристику детекции "в движении на транспорте" (без ML, на основе энергии сигнала)
 *
 * Работает на частоте SENSOR_DELAY_GAME (~50 Гц) либо выше, если устройство
 * поддерживает HIGH_SAMPLING_RATE_SENSORS.
 */
class SensorFusionEngine(context: Context) : SensorEventListener {

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val linearAccelSensor = sensorManager.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION)
    private val gyroSensor = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)

    // Отдельный фильтр Калмана на каждую ось — так мы не смешиваем шум разных
    // физических величин в одной модели.
    private val kalmanX = KalmanFilter1D(processNoise = 0.01, measurementNoise = 0.30)
    private val kalmanY = KalmanFilter1D(processNoise = 0.01, measurementNoise = 0.30)
    private val kalmanYaw = KalmanFilter1D(processNoise = 0.015, measurementNoise = 0.25)

    // Экспоненциальное скользящее среднее для оценки "фоновой энергии" вибрации
    // — нужно, чтобы отличать мелкую дорожную тряску от реального манёвра.
    private var vibrationFloor = 0.15f
    private val vibrationFloorAlpha = 0.02f

    private val _motionCue = MutableStateFlow(MotionCueVector())
    val motionCue: StateFlow<MotionCueVector> = _motionCue

    private val _vehicleState = MutableStateFlow(VehicleMotionState.IDLE)
    val vehicleState: StateFlow<VehicleMotionState> = _vehicleState

    private var lastGyroZ = 0f
    private var drivingEnergyAccumulator = 0f
    private var samplesInWindow = 0
    private val activityWindowSize = 100 // ~2 сек при 50Гц

    fun start() {
        val samplingPeriodUs = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            SensorManager.SENSOR_DELAY_GAME else SensorManager.SENSOR_DELAY_GAME

        linearAccelSensor?.let {
            sensorManager.registerListener(this, it, samplingPeriodUs, samplingPeriodUs)
        }
        gyroSensor?.let {
            sensorManager.registerListener(this, it, samplingPeriodUs, samplingPeriodUs)
        }
    }

    fun stop() {
        sensorManager.unregisterListener(this)
    }

    override fun onSensorChanged(event: SensorEvent) {
        when (event.sensor.type) {
            Sensor.TYPE_LINEAR_ACCELERATION -> handleLinearAcceleration(event)
            Sensor.TYPE_GYROSCOPE -> handleGyroscope(event)
        }
    }

    private fun handleLinearAcceleration(event: SensorEvent) {
        // X — боковое ускорение (повороты), Y — продольное (торможение/разгон в портретной ориентации телефона)
        val rawX = event.values[0].toDouble()
        val rawY = event.values[1].toDouble()

        val filteredX = kalmanX.update(rawX).toFloat()
        val filteredY = kalmanY.update(rawY).toFloat()

        // Адаптация чувствительности: на резких сигналах уменьшаем измерительный шум,
        // чтобы фильтр быстрее "верил" в реальный манёвр, а не сглаживал его в кашу.
        val magnitude = abs(filteredX) + abs(filteredY)
        val adaptiveR = when {
            magnitude > 3.0 -> 0.12
            magnitude > 1.2 -> 0.22
            else -> 0.35
        }
        kalmanX.setMeasurementNoise(adaptiveR)
        kalmanY.setMeasurementNoise(adaptiveR)

        // Нормализация в диапазон UI [-1, 1]. MAX_LATERAL_G и MAX_LONG_G — эмпирические
        // пороги "комфортного" ускорения легкового авто (~0.35g для поворота, ~0.4g для торможения).
        val lateral = (filteredX / MAX_LATERAL_MS2).coerceIn(-1f, 1f)
        val longitudinal = (filteredY / MAX_LONGITUDINAL_MS2).coerceIn(-1f, 1f)

        updateVibrationFloor(magnitude.toFloat())
        val intensity = calculateIntensity(magnitude.toFloat())

        _motionCue.value = MotionCueVector(
            lateralOffset = lateral,
            longitudinalOffset = longitudinal,
            yawRate = _motionCue.value.yawRate,
            intensity = intensity,
            timestampNs = event.timestamp
        )

        accumulateActivityEnergy(magnitude.toFloat())
    }

    private fun handleGyroscope(event: SensorEvent) {
        val rawYaw = event.values[2].toDouble() // вращение вокруг вертикальной оси (Z)
        val filteredYaw = kalmanYaw.update(rawYaw).toFloat()
        lastGyroZ = filteredYaw

        _motionCue.value = _motionCue.value.copy(yawRate = filteredYaw)
    }

    /** Скользящая оценка фонового уровня вибрации (для будущей калибровки под тип дороги). */
    private fun updateVibrationFloor(magnitude: Float) {
        vibrationFloor = vibrationFloor * (1 - vibrationFloorAlpha) + magnitude * vibrationFloorAlpha
    }

    private fun calculateIntensity(magnitude: Float): Float {
        val delta = max(0f, magnitude - vibrationFloor)
        return min(1f, delta / 2.5f)
    }

    /**
     * Простая эвристика авто-детекции "едем на транспорте", без обращения
     * к Activity Recognition API (используется как fallback / доп. сигнал —
     * см. DrivingDetectionReceiver для системного ActivityRecognitionClient).
     */
    private fun accumulateActivityEnergy(magnitude: Float) {
        drivingEnergyAccumulator += magnitude
        samplesInWindow++

        if (samplesInWindow >= activityWindowSize) {
            val avgEnergy = drivingEnergyAccumulator / samplesInWindow
            _vehicleState.value = if (avgEnergy in 0.25f..8.0f) {
                VehicleMotionState.DRIVING
            } else {
                VehicleMotionState.IDLE
            }
            drivingEnergyAccumulator = 0f
            samplesInWindow = 0
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) { /* no-op */ }

    companion object {
        private const val MAX_LATERAL_MS2 = 3.5f
        private const val MAX_LONGITUDINAL_MS2 = 4.0f
    }
}
