package com.motioncues

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.motioncues.activity.DrivingDetector
import com.motioncues.overlay.OverlayService

/**
 * Единственный экран приложения: onboarding-разрешения + ручной переключатель.
 * Основная работа (сенсоры, оверлей) идёт в OverlayService, а не здесь —
 * Activity может быть уничтожена системой, сервис — нет (foreground).
 */
class MainActivity : ComponentActivity() {

    private lateinit var drivingDetector: DrivingDetector

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* результат обрабатывается через recheckPermissions() при recompose */ }

    private val activityRecognitionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> if (granted) drivingDetector.register() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        drivingDetector = DrivingDetector(applicationContext)

        setContent {
            MaterialTheme {
                PermissionOnboardingScreen(
                    onRequestOverlay = ::requestOverlayPermission,
                    onRequestActivityRecognition = ::requestActivityRecognitionPermission,
                    onRequestNotifications = ::requestNotificationPermission,
                    onToggleManual = ::toggleManualTracking,
                    hasOverlayPermission = { Settings.canDrawOverlays(this) }
                )
            }
        }
    }

    private fun requestOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        }
    }

    private fun requestActivityRecognitionPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            activityRecognitionLauncher.launch(Manifest.permission.ACTIVITY_RECOGNITION)
        } else {
            drivingDetector.register()
        }
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private var manualTrackingOn = false
    private fun toggleManualTracking() {
        manualTrackingOn = !manualTrackingOn
        if (manualTrackingOn) OverlayService.start(this) else OverlayService.stopNow(this)
    }

    override fun onDestroy() {
        super.onDestroy()
        // Оверлей/сенсоры сознательно НЕ останавливаем здесь — работой владеет
        // foreground-сервис и он должен пережить уничтожение Activity.
    }
}

@Composable
fun PermissionOnboardingScreen(
    onRequestOverlay: () -> Unit,
    onRequestActivityRecognition: () -> Unit,
    onRequestNotifications: () -> Unit,
    onToggleManual: () -> Unit,
    hasOverlayPermission: () -> Boolean
) {
    var manualEnabled by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically)
    ) {
        Text("Защита от укачивания", style = MaterialTheme.typography.headlineMedium)
        Text(
            "Приложению нужны 3 разрешения, чтобы работать в фоне поверх других приложений (карт, видео и т.д.)",
            style = MaterialTheme.typography.bodyMedium
        )

        OutlinedButton(onClick = onRequestOverlay, modifier = Modifier.fillMaxWidth()) {
            Text(if (hasOverlayPermission()) "✓ Оверлей разрешён" else "1. Разрешить оверлей поверх экрана")
        }
        OutlinedButton(onClick = onRequestActivityRecognition, modifier = Modifier.fillMaxWidth()) {
            Text("2. Разрешить распознавание активности (авто старт/стоп)")
        }
        OutlinedButton(onClick = onRequestNotifications, modifier = Modifier.fillMaxWidth()) {
            Text("3. Разрешить уведомления (обязательно для foreground-сервиса)")
        }

        Spacer(Modifier.height(24.dp))

        Button(
            onClick = {
                manualEnabled = !manualEnabled
                onToggleManual()
            },
            modifier = Modifier.fillMaxWidth().height(56.dp)
        ) {
            Text(if (manualEnabled) "Остановить вручную" else "Запустить вручную (тест)")
        }

        Text(
            "При включённом авто-режиме сервис сам запустится, когда система определит, что вы в транспорте.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}
