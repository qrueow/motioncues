package com.motioncues

import android.app.Application
import android.os.Build
import androidx.core.content.ContextCompat
import com.motioncues.activity.DrivingDetector

class MotionCuesApp : Application() {

    lateinit var drivingDetector: DrivingDetector
        private set

    override fun onCreate() {
        super.onCreate()
        drivingDetector = DrivingDetector(this)

        // Регистрируем слушатель Activity Recognition сразу при старте приложения,
        // если разрешение уже выдано (иначе регистрация произойдёт из MainActivity
        // после запроса разрешения пользователем).
        if (hasActivityRecognitionPermission()) {
            drivingDetector.register()
        }
    }

    private fun hasActivityRecognitionPermission(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return true
        return ContextCompat.checkSelfPermission(
            this, android.Manifest.permission.ACTIVITY_RECOGNITION
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED
    }
}
