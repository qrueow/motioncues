package com.motioncues.activity

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import com.google.android.gms.location.ActivityRecognition
import com.google.android.gms.location.ActivityRecognitionResult
import com.google.android.gms.location.DetectedActivity
import com.motioncues.overlay.OverlayService

/**
 * Обёртка над Google Play Services Activity Recognition API.
 * Запускает/останавливает OverlayService (foreground service + оверлей)
 * при переходе IN_VEHICLE <-> прочие состояния, с гистерезисом по confidence,
 * чтобы не дёргать сервис на каждом дребезге классификатора.
 */
class DrivingDetector(private val context: Context) {

    private val client = ActivityRecognition.getClient(context)
    private var pendingIntent: PendingIntent? = null

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            if (!ActivityRecognitionResult.hasResult(intent)) return
            val result = ActivityRecognitionResult.extractResult(intent) ?: return

            val mostProbable = result.mostProbableActivity
            val inVehicle = mostProbable.type == DetectedActivity.IN_VEHICLE &&
                mostProbable.confidence >= CONFIDENCE_THRESHOLD

            if (inVehicle) {
                OverlayService.start(ctx)
            } else {
                // Небольшая задержка перед остановкой отдана самому OverlayService
                // (см. STOP_GRACE_PERIOD_MS), чтобы избежать мигания на светофорах.
                OverlayService.scheduleStop(ctx)
            }
        }
    }

    fun register() {
        val intent = Intent(ACTION_ACTIVITY_UPDATE).setPackage(context.packageName)
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
            PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        else PendingIntent.FLAG_UPDATE_CURRENT

        pendingIntent = PendingIntent.getBroadcast(context, REQUEST_CODE, intent, flags)

        context.registerReceiver(
            receiver, IntentFilter(ACTION_ACTIVITY_UPDATE),
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) Context.RECEIVER_EXPORTED else 0
        )

        pendingIntent?.let { pi ->
            client.requestActivityUpdates(DETECTION_INTERVAL_MS, pi)
        }
    }

    fun unregister() {
        pendingIntent?.let { client.removeActivityUpdates(it) }
        runCatching { context.unregisterReceiver(receiver) }
    }

    companion object {
        private const val ACTION_ACTIVITY_UPDATE = "com.motioncues.ACTIVITY_UPDATE"
        private const val REQUEST_CODE = 1001
        private const val DETECTION_INTERVAL_MS = 15_000L
        private const val CONFIDENCE_THRESHOLD = 65
    }
}
