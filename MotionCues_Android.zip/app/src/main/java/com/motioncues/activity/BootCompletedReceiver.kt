package com.motioncues.activity

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * После перезагрузки устройства подписка на ActivityRecognitionClient слетает.
 * Здесь мы просто заново регистрируем её — без запуска самого overlay-сервиса
 * (он стартует только когда реально обнаружено движение в транспорте).
 */
class BootCompletedReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            DrivingDetector(context.applicationContext).register()
        }
    }
}
