package com.motioncues.overlay

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.unit.dp
import com.motioncues.sensor.MotionCueVector
import kotlinx.coroutines.flow.StateFlow
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * Периферийная сетка точек, реагирующая на MotionCueVector.
 * Рендерится на весь экран поверх системного UI (WindowManager overlay),
 * с прозрачным центром — точки живут только по краям, как в Vehicle Motion Cues,
 * чтобы не перекрывать основной контент (карту, видео и т.д.).
 *
 * Анимация ведётся через Compose Animatable + LaunchedEffect, дискретных
 * setState() на каждый sensor-тик НЕТ — вместо этого мы плавно догоняем
 * (spring-like tween) целевое значение, что даёт стабильные 60 FPS
 * независимо от частоты сенсоров (может быть 50-200 Гц).
 */
@Composable
fun MotionCuesOverlay(motionCueFlow: StateFlow<MotionCueVector>) {
    val cue by motionCueFlow.collectAsState()

    // Целевые значения обновляются мгновенно из сенсоров,
    // а фактические анимируемые — плавно интерполируются к ним.
    val animatedLateral = remember { Animatable(0f) }
    val animatedLongitudinal = remember { Animatable(0f) }
    val animatedYaw = remember { Animatable(0f) }
    var animatedIntensity by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(cue.lateralOffset) {
        animatedLateral.animateTo(cue.lateralOffset, tween(durationMillis = 90))
    }
    LaunchedEffect(cue.longitudinalOffset) {
        animatedLongitudinal.animateTo(cue.longitudinalOffset, tween(durationMillis = 90))
    }
    LaunchedEffect(cue.yawRate) {
        animatedYaw.animateTo(cue.yawRate, tween(durationMillis = 70))
    }
    LaunchedEffect(cue.intensity) {
        animatedIntensity = cue.intensity
    }

    Canvas(
        modifier = Modifier
            .background(Color.Transparent)
    ) {
        drawPeripheralDotGrid(
            lateral = animatedLateral.value,
            longitudinal = animatedLongitudinal.value,
            yaw = animatedYaw.value,
            intensity = animatedIntensity
        )
    }
}

/**
 * Основная функция отрисовки. Точки размещены только в периферийной зоне
 * (кольцо от 70% до 98% диагонали от центра), плотность сетки ~ 14x24,
 * но реально рисуются только те, что попадают в кольцо — недорого по GPU.
 */
private fun DrawScope.drawPeripheralDotGrid(
    lateral: Float,
    longitudinal: Float,
    yaw: Float,
    intensity: Float
) {
    val w = size.width
    val h = size.height
    val centerX = w / 2f
    val centerY = h / 2f
    val maxRadius = min(w, h) / 2f

    val innerRingRatio = 0.62f
    val outerRingRatio = 0.98f

    val cols = 16
    val rows = 26
    val dotRadius = 3.5f + intensity * 2.5f

    // Смещение всей сетки: боковое ускорение двигает точки горизонтально
    // в направлении, ПРОТИВОПОЛОЖНОМ ускорению (компенсирующий визуальный cue,
    // как в реализации Apple — мозг воспринимает это как внешний горизонт).
    val shiftX = -lateral * maxRadius * 0.18f
    val shiftY = -longitudinal * maxRadius * 0.18f
    val rotationRad = -yaw * 0.35f

    for (row in 0 until rows) {
        for (col in 0 until cols) {
            val angle = (col.toFloat() / cols) * (2 * Math.PI.toFloat())
            val radiusRatio = innerRingRatio + (outerRingRatio - innerRingRatio) * (row.toFloat() / rows)
            val radius = radiusRatio * maxRadius

            val baseX = centerX + radius * cos(angle + rotationRad)
            val baseY = centerY + radius * sin(angle + rotationRad)

            val x = baseX + shiftX
            val y = baseY + shiftY

            val alpha = (0.15f + intensity * 0.55f).coerceIn(0.1f, 0.85f)

            drawCircle(
                color = Color.White.copy(alpha = alpha),
                radius = dotRadius,
                center = Offset(x, y)
            )
        }
    }
}
